package com.tyss.jwtrolebased;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtRoleBasedApplicationTests {

	@Test
	void contextLoads() {
	}

}
