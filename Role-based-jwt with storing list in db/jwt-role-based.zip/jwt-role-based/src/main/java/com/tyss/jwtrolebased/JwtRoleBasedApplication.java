package com.tyss.jwtrolebased;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtRoleBasedApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtRoleBasedApplication.class, args);
	}

}
